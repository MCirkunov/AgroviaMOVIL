# AgroVIA móvil

Versión Dash adaptable a teléfonos, sin marco visual de dispositivo.

## Publicar como app separada en Render

1. Crea un repositorio nuevo en GitHub.
2. Sube `AgroVIA_Movil_Render.zip` a la raíz del repositorio. No hace falta subir carpetas ni descomprimirlo en GitHub.
3. En Render, configura el **Build Command** como `python -c "import zipfile; zipfile.ZipFile('AgroVIA_Movil_Render.zip').extractall('.')" && pip install -r requirements.txt`.
4. Configura el **Start Command** como `gunicorn app:server --bind 0.0.0.0:$PORT` y vuelve a desplegar.
5. Comparte la URL HTTPS generada por Render. Ábrela desde el teléfono para usar la interfaz a pantalla completa.

El documento `AgroVIA_Terminos_y_Condiciones.docx` puede quedarse en la raíz; la app lo busca allí. La demo usa datos de ejemplo y no sincroniza cambios entre usuarios.